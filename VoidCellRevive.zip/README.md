# VoidCellRevive
 A mod to revive players at the start of each round of the Void Arena

Updated to Post-Anniversary Update